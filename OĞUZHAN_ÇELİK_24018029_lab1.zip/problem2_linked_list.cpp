/**
 * YZM2031 - Lab Assignment 1
 * Problem 2: Singly Linked List Implementation
 * 
 * Student Name: [OĞUZHAN ÇELİK]
 * Student ID: [24018029]
 * 
 * Instructions: Implement the TODO sections below
 */

#include <iostream>
using namespace std;

class LinkedList {
private:
    struct Node {
        int data;
        Node* next;
        Node(int val) : data(val), next(nullptr) {}
    };

    Node* head;
    int size;

public:
    // Constructor
    LinkedList() : head(nullptr), size(0) {}

    // Destructor
    ~LinkedList() {
        // TODO: Free all nodes
        // 1. Traverse the list
        // 2. Delete each node
        // Hint: Save the next pointer before deleting current node
        while (head!=NULL){
            Node* temp=head;
            head=head->next;
            delete temp;
        }
        
    }

    // Insert at beginning
    void insertFront(int value) {
        // TODO: Implement insertFront
        // 1. Create a new node
        // 2. Set new node's next to current head
        // 3. Update head to new node
        // 4. Increment size
        Node* newNode;
        newNode = new Node(value);
        newNode->next = head;
        head = newNode;
        size++;
    }

    // Insert at end
    void insertBack(int value) {
        // TODO: Implement insertBack
        // 1. Create a new node
        // 2. If list is empty, set head to new node
        // 3. Otherwise, traverse to the last node
        // 4. Set last node's next to new node
        // 5. Increment size
        Node* newNode;
        newNode = new Node(value);
        if(size==0){
            head=newNode;
            return;
        }
        Node* temp;
        while(temp->next!=NULL) temp=temp->next;
        temp->next = newNode;
        size++;
    }

    // Insert at specific position
    void insertAt(int index, int value) {
        // TODO: Implement insertAt
        // 1. Validate index (0 <= index <= size)
        // 2. If index is 0, call insertFront
        // 3. Otherwise, traverse to node at index-1
        // 4. Create new node
        // 5. Link new node between current node and next node
        // 6. Increment size
        if(index < 0 || index > size) throw runtime_error("index is invalid!");
        if(index == 0) {
            insertFront(value);
            return;
        }
        int i;
        Node* temp=head;
        for(i=1;i<index;i++) temp=temp->next;
        Node* newNode;
        newNode = new Node(value);
        newNode->next = temp->next;
        temp->next = newNode;
        size++;
    }

    // Delete first element
    void deleteFront() {
        // TODO: Implement deleteFront
        // 1. Check if list is empty
        // 2. Save head pointer
        // 3. Move head to next node
        // 4. Delete old head
        // 5. Decrement size
        if(size == 0) throw runtime_error("List is already empty!");
        Node* temp;
        temp = head;
        head = head->next;
        delete temp;
        size--;
    }

    // Delete last element
    void deleteBack() {
        // TODO: Implement deleteBack
        // 1. Check if list is empty
        // 2. If only one node, delete it and set head to nullptr
        // 3. Otherwise, traverse to second-to-last node
        // 4. Delete last node
        // 5. Set second-to-last node's next to nullptr
        // 6. Decrement size
        if(size == 0) throw runtime_error("List is already empty!");
        int i;
        Node* temp;
        temp = head;
        if(size == 1){
            delete temp;
            head = nullptr;
            return;
        }
        for(i=1;i<size-1;i++) temp= temp->next;
        delete temp->next;
        temp->next = nullptr;
        size--;
    }

    // Search for value and return index (-1 if not found)
    int search(int value) {
        // TODO: Implement search
        // 1. Traverse the list
        // 2. Keep track of index
        // 3. If value found, return index
        // 4. If not found, return -1
        if(size == 0) throw runtime_error("list is empty can't search a value");
        Node* temp;
        temp = head;
        int index=0;
        while(temp != NULL && temp->data != value){
            index++;
            temp = temp->next;
        }
        if(index == size) return -1;
        return index;
    }

    // Reverse the list
    void reverse() {
        // TODO: Implement reverse
        // 1. Use three pointers: prev, current, next
        // 2. Initialize prev = nullptr, current = head
        // 3. Traverse the list:
        //    - Save next node
        //    - Reverse current node's pointer
        //    - Move prev and current forward
        // 4. Update head to prev
        Node* prev;
        Node* current;
        Node* next;
        current = head;
        prev = nullptr;

        while(current != NULL){
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }

    // Print all elements
    void print() const {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data;
            if (current->next != nullptr) {
                cout << " → ";
            }
            current = current->next;
        }
        cout << " → nullptr" << endl;
    }

    // Return size
    int getSize() const {
        return size;
    }
};

// Test cases
int main() {
    cout << "=== Testing Linked List ===" << endl << endl;

    LinkedList list;

    // Test 1: Insert operations
    cout << "Test 1: Insert operations" << endl;
    list.insertFront(10);
    list.insertFront(5);
    list.insertBack(20);
    list.insertBack(25);
    cout << "List: ";
    list.print();  // Expected: 5 → 10 → 20 → 25 → nullptr
    cout << "Size: " << list.getSize() << endl;
    cout << endl;

    // Test 2: Insert at position
    cout << "Test 2: Insert 15 at index 2" << endl;
    list.insertAt(2, 15);
    cout << "List: ";
    list.print();  // Expected: 5 → 10 → 15 → 20 → 25 → nullptr
    cout << endl;

    // Test 3: Search
    cout << "Test 3: Search operations" << endl;
    cout << "Index of 15: " << list.search(15) << endl;  // Expected: 2
    cout << "Index of 100: " << list.search(100) << endl;  // Expected: -1
    cout << endl;

    // Test 4: Delete operations
    cout << "Test 4: Delete front" << endl;
    list.deleteFront();
    cout << "List: ";
    list.print();  // Expected: 10 → 15 → 20 → 25 → nullptr
    cout << endl;

    cout << "Test 5: Delete back" << endl;
    list.deleteBack();
    cout << "List: ";
    list.print();  // Expected: 10 → 15 → 20 → nullptr
    cout << endl;

    // Test 6: Reverse
    cout << "Test 6: Reverse list" << endl;
    list.reverse();
    cout << "List: ";
    list.print();  // Expected: 20 → 15 → 10 → nullptr
    cout << endl;

    cout << "=== All tests completed ===" << endl;

    return 0;
}

